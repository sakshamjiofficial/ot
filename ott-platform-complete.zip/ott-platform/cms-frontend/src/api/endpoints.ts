import { apiGet, apiPost, apiPut, apiDelete, apiClient } from './client';
import type {
  AuthResult, Content, Genre, TranscodingJob, QueueStats,
  AdminUser, DashboardStats, Banner, NotificationPayload,
  UploadInitResponse, UploadedPart,
} from '@/types';

// ─── Auth ──────────────────────────────────────────────────────

export const authApi = {
  login:    (email: string, password: string) =>
    apiPost<AuthResult>('/auth/login', { email, password }),
  me:       () => apiGet<AuthResult['user']>('/auth/me'),
  logout:   () => apiPost<void>('/auth/logout'),
  refresh:  (refreshToken: string) =>
    apiPost<{ accessToken: string; refreshToken: string; expiresIn: number }>(
      '/auth/refresh', { refreshToken },
    ),
};

// ─── Content ───────────────────────────────────────────────────

export const contentApi = {
  listMovies:  (params?: Record<string, any>) => apiGet<any>('/movies', params),
  listSeries:  (params?: Record<string, any>) => apiGet<any>('/series', params),
  getById:     (id: string)  => apiGet<Content>(`/admin/content/${id}`),
  create:      (data: any)   => apiPost<Content>('/admin/content', data),
  update:      (id: string, data: any) => apiPut<Content>(`/admin/content/${id}`, data),
  delete:      (id: string)  => apiDelete(`/admin/content/${id}`),
  stats:       ()            => apiGet<any>('/admin/content/stats'),

  // Seasons
  createSeason: (contentId: string, data: any) =>
    apiPost(`/admin/series/${contentId}/seasons`, data),
  getSeasons:   (contentId: string) => apiGet<any>(`/series/${contentId}/seasons`),

  // Episodes
  createEpisode: (seasonId: string, contentId: string, data: any) =>
    apiPost(`/admin/seasons/${seasonId}/episodes?contentId=${contentId}`, data),
  updateEpisode: (id: string, data: any) => apiPut(`/admin/episodes/${id}`, data),
  deleteEpisode: (id: string) => apiDelete(`/admin/episodes/${id}`),

  // Genres
  listGenres:  () => apiGet<Genre[]>('/genres'),
  createGenre: (name: string) => apiPost<Genre>('/admin/genres', { name }),
};

// ─── Upload ────────────────────────────────────────────────────

export const uploadApi = {
  initiate: (data: {
    contentId?: string; episodeId?: string;
    filename: string; fileSize: number; mimeType: string; partCount: number;
  }) => apiPost<UploadInitResponse>('/upload/initiate', data),

  complete: (data: {
    uploadId: string; key: string; videoAssetId: string;
    parts: UploadedPart[]; autoTranscode?: boolean;
  }) => apiPost<{ url: string; jobId?: string }>('/upload/complete', data),

  abort: (key: string, uploadId: string) =>
    apiDelete(`/upload/abort`),   // body sent separately

  status:     (videoAssetId: string) =>
    apiGet<TranscodingJob>(`/upload/status/${videoAssetId}`),
  retryJob:   (videoAssetId: string) =>
    apiPost<void>(`/upload/retry/${videoAssetId}`),
  listJobs:   (status?: string, limit = 50) =>
    apiGet<TranscodingJob[]>('/upload/jobs', { status, limit }),
  queueStats: () => apiGet<QueueStats>('/upload/queue-stats'),
};

// ─── Users ─────────────────────────────────────────────────────

export const usersApi = {
  list:       (params?: { page?: number; limit?: number; search?: string }) =>
    apiGet<any>('/users', params),
  getById:    (id: string) => apiGet<AdminUser>(`/users/${id}`),
  deactivate: (id: string) => apiDelete(`/users/${id}`),
};

// ─── Banners ───────────────────────────────────────────────────

export const bannersApi = {
  list:   () => apiGet<Banner[]>('/banners'),
  create: (data: any) => apiPost<Banner>('/admin/banners', data),
  update: (id: string, data: any) => apiPut<Banner>(`/admin/banners/${id}`, data),
  delete: (id: string) => apiDelete(`/admin/banners/${id}`),
};

// ─── Dashboard ─────────────────────────────────────────────────

export const dashboardApi = {
  stats: async (): Promise<DashboardStats> => {
    const [contentStats, userStats, queueStats] = await Promise.all([
      contentApi.stats(),
      usersApi.list({ limit: 1 }),
      uploadApi.queueStats(),
    ]);

    return {
      totalUsers:    userStats?.meta?.total    ?? 0,
      activeUsers:   userStats?.meta?.total    ?? 0,
      newUsersToday: 0,
      totalMovies:   contentStats?.totalMovies  ?? 0,
      totalSeries:   contentStats?.totalSeries  ?? 0,
      published:     contentStats?.published    ?? 0,
      processing:    contentStats?.processing   ?? 0,
      queueStats:    queueStats ?? { waiting: 0, active: 0, completed: 0, failed: 0, delayed: 0 },
      topContent:    [],
    };
  },
};

// ─── Notifications ─────────────────────────────────────────────

export const notificationsApi = {
  send: (payload: NotificationPayload) =>
    apiPost<void>('/admin/notifications/send', payload),
};

// ─── App Config ────────────────────────────────────────────────

export const configApi = {
  getAll: () => apiGet<Record<string, string>>('/admin/config'),
  set:    (key: string, value: string) =>
    apiPost<void>('/admin/config', { key, value }),
};
