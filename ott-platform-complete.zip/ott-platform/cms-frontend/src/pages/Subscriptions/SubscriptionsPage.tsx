import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  BadgeDollarSign, Users, TrendingUp, Tag,
  Plus, ToggleLeft, ToggleRight, Trash2, RefreshCw,
} from 'lucide-react';
import { apiGet, apiPost, apiDelete } from '@/api/client';
import {
  StatCard, Card, Button, Input, Select,
  ConfirmDialog, StatusBadge, Badge, Spinner,
} from '@/components/UI';
import { DataTable } from '@/components/DataTable/DataTable';
import { formatDate, formatNumber } from '@/utils/cn';
import toast from 'react-hot-toast';

// ─── API helpers ──────────────────────────────────────────────
const fetchStats    = () => apiGet<any>('/admin/subscriptions/stats');
const fetchCoupons  = () => apiGet<any[]>('/admin/coupons');
const createCoupon  = (data: any) => apiPost('/admin/coupons', data);
const toggleCoupon  = (id: string) => apiPost(`/admin/coupons/${id}/toggle`, {});
const deleteCoupon  = (id: string) => apiDelete(`/admin/coupons/${id}`);

// ─── Main Page ────────────────────────────────────────────────

export default function SubscriptionsPage() {
  const [activeTab, setActiveTab] = useState<'overview' | 'coupons'>('overview');

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Tabs */}
      <div className="flex gap-1 rounded-lg border border-surface-600 bg-surface-800 p-1 w-fit">
        {(['overview', 'coupons'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`rounded-md px-5 py-2 text-sm font-medium capitalize transition-colors ${
              activeTab === tab
                ? 'bg-brand-500 text-white'
                : 'text-surface-300 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && <OverviewTab />}
      {activeTab === 'coupons'  && <CouponsTab />}
    </div>
  );
}

// ─── Overview Tab ─────────────────────────────────────────────

function OverviewTab() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['sub-stats'],
    queryFn:  fetchStats,
    refetchInterval: 60_000,
  });

  if (isLoading) return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Active Subscriptions" value={formatNumber(stats?.activeSubscriptions ?? 0)} icon={<Users size={18} />}          color="green" />
        <StatCard label="Free Trials"           value={formatNumber(stats?.trialSubscriptions  ?? 0)} icon={<Tag size={18} />}             color="blue"  />
        <StatCard label="Expired"               value={formatNumber(stats?.expiredSubscriptions ?? 0)} icon={<RefreshCw size={18} />}      color="default" />
        <StatCard label="Total Revenue"         value={`₹${formatNumber(stats?.totalRevenueInr ?? 0)}`} icon={<TrendingUp size={18} />}   color="red" />
      </div>

      <Card>
        <h3 className="mb-4 font-semibold text-white">Revenue Breakdown</h3>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 text-sm">
          {[
            { label: 'Monthly Plans',  value: '—' },
            { label: 'Annual Plans',   value: '—' },
            { label: 'Family Plans',   value: '—' },
            { label: 'Razorpay',       value: '—' },
            { label: 'Google Play',    value: '—' },
            { label: 'Coupon Savings', value: '—' },
          ].map(({ label, value }) => (
            <div key={label} className="rounded-lg bg-surface-700 px-4 py-3">
              <p className="text-surface-400 text-xs">{label}</p>
              <p className="mt-1 text-lg font-bold text-white">{value}</p>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-surface-400">
          Detailed analytics coming in Phase 2G. Connect your Razorpay dashboard for real-time revenue data.
        </p>
      </Card>

      <Card>
        <h3 className="mb-2 font-semibold text-white">Subscription Plans</h3>
        <p className="mb-4 text-xs text-surface-400">Configured via database seed. Update prices via SQL migration.</p>
        <div className="space-y-3">
          {[
            { name: 'Free',    price: '₹0',   devices: 1, quality: '480p',  color: 'text-surface-300' },
            { name: 'Basic',   price: '₹99',  devices: 2, quality: '720p',  color: 'text-blue-400' },
            { name: 'Premium', price: '₹199', devices: 4, quality: '1080p', color: 'text-brand-400' },
            { name: 'Family',  price: '₹299', devices: 6, quality: '1080p', color: 'text-green-400' },
          ].map((plan) => (
            <div key={plan.name} className="flex items-center justify-between rounded-lg bg-surface-700 px-4 py-3">
              <div className="flex items-center gap-3">
                <BadgeDollarSign size={16} className={plan.color} />
                <span className={`font-semibold ${plan.color}`}>{plan.name}</span>
              </div>
              <div className="flex gap-6 text-sm text-surface-300">
                <span>{plan.price}/month</span>
                <span>{plan.devices} device{plan.devices > 1 ? 's' : ''}</span>
                <span>Up to {plan.quality}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ─── Coupons Tab ──────────────────────────────────────────────

function CouponsTab() {
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [deleteId, setDeleteId]     = useState<string | null>(null);

  const { data: coupons = [], isLoading } = useQuery({
    queryKey: ['admin-coupons'],
    queryFn:  fetchCoupons,
    select:   (d) => Array.isArray(d) ? d : [],
  });

  const toggleMut = useMutation({
    mutationFn: (id: string) => toggleCoupon(id),
    onSuccess:  () => queryClient.invalidateQueries({ queryKey: ['admin-coupons'] }),
    onError:    () => toast.error('Failed to toggle coupon'),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteCoupon(id),
    onSuccess:  () => {
      queryClient.invalidateQueries({ queryKey: ['admin-coupons'] });
      toast.success('Coupon deleted');
      setDeleteId(null);
    },
    onError: () => toast.error('Failed to delete coupon'),
  });

  const columns = [
    {
      key:    'code',
      header: 'Code',
      render: (row: any) => (
        <code className="rounded bg-surface-600 px-2 py-0.5 text-sm font-bold text-brand-400">{row.code}</code>
      ),
    },
    {
      key:    'discount',
      header: 'Discount',
      render: (row: any) => (
        <span className="font-semibold text-green-400">
          {row.discountType === 'percent' ? `${row.discountValue}%` : `₹${row.discountValue}`} off
        </span>
      ),
    },
    {
      key:    'usage',
      header: 'Usage',
      render: (row: any) => (
        <span className="text-surface-200">
          {row.usedCount}{row.maxUses ? `/${row.maxUses}` : ''}
        </span>
      ),
    },
    {
      key:    'expires',
      header: 'Expires',
      render: (row: any) => (
        <span className="text-xs text-surface-300">
          {row.expiresAt ? formatDate(row.expiresAt) : 'Never'}
        </span>
      ),
    },
    {
      key:    'status',
      header: 'Status',
      render: (row: any) => <StatusBadge status={row.isActive ? 'published' : 'archived'} />,
    },
  ];

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <p className="text-sm text-surface-300">{coupons.length} coupon{coupons.length !== 1 ? 's' : ''}</p>
        <Button icon={<Plus size={15} />} onClick={() => setShowCreate(true)}>Create Coupon</Button>
      </div>

      <Card padding={false}>
        <DataTable
          columns={columns}
          data={coupons}
          isLoading={isLoading}
          keyField="id"
          emptyMessage="No coupons yet"
          rowActions={(row: any) => (
            <div className="flex justify-end gap-1">
              <button
                onClick={() => toggleMut.mutate(row.id)}
                className="rounded-lg p-1.5 text-surface-400 hover:bg-surface-600 hover:text-white transition-colors"
                title={row.isActive ? 'Deactivate' : 'Activate'}
              >
                {row.isActive ? <ToggleRight size={16} className="text-green-400" /> : <ToggleLeft size={16} />}
              </button>
              <button
                onClick={() => setDeleteId(row.id)}
                className="rounded-lg p-1.5 text-surface-400 hover:bg-red-500/10 hover:text-red-400 transition-colors"
                title="Delete"
              >
                <Trash2 size={14} />
              </button>
            </div>
          )}
        />
      </Card>

      {showCreate && (
        <CreateCouponModal
          onClose={() => setShowCreate(false)}
          onCreated={() => {
            queryClient.invalidateQueries({ queryKey: ['admin-coupons'] });
            setShowCreate(false);
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteId}
        title="Delete Coupon"
        description="This will permanently delete the coupon code. Any in-flight payments using this code will still be honoured."
        confirmLabel="Delete"
        danger
        onConfirm={() => deleteId && deleteMut.mutate(deleteId)}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

// ─── Create Coupon Modal ──────────────────────────────────────

function CreateCouponModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [form, setForm] = useState({
    code:         '',
    discountType: 'percent',
    discountValue: '',
    maxUses:      '',
    minAmountInr: '',
    planId:       '',
    expiresAt:    '',
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await createCoupon({
        code:         form.code.toUpperCase(),
        discountType: form.discountType,
        discountValue: parseFloat(form.discountValue),
        maxUses:      form.maxUses      ? parseInt(form.maxUses)      : null,
        minAmountInr: form.minAmountInr ? parseFloat(form.minAmountInr) : 0,
        planId:       form.planId       ? parseInt(form.planId)       : null,
        expiresAt:    form.expiresAt    ? new Date(form.expiresAt).toISOString() : null,
      });
      toast.success(`Coupon ${form.code.toUpperCase()} created`);
      onCreated();
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to create coupon');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-lg rounded-xl border border-surface-600 bg-surface-800 p-6 shadow-2xl animate-slide-up">
        <h3 className="mb-5 font-semibold text-white text-lg">Create Coupon</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Code"
              required
              placeholder="SAVE50"
              value={form.code}
              onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
            />
            <Select
              label="Discount Type"
              value={form.discountType}
              onChange={(e) => setForm({ ...form, discountType: e.target.value })}
              options={[
                { value: 'percent', label: 'Percent (%)' },
                { value: 'flat',    label: 'Flat (₹)' },
              ]}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input
              label={form.discountType === 'percent' ? 'Discount %' : 'Discount ₹'}
              required
              type="number"
              min="1"
              max={form.discountType === 'percent' ? '100' : undefined}
              placeholder={form.discountType === 'percent' ? '50' : '99'}
              value={form.discountValue}
              onChange={(e) => setForm({ ...form, discountValue: e.target.value })}
            />
            <Input
              label="Max Uses (blank = unlimited)"
              type="number"
              min="1"
              placeholder="e.g. 500"
              value={form.maxUses}
              onChange={(e) => setForm({ ...form, maxUses: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Min Order ₹"
              type="number"
              placeholder="0"
              value={form.minAmountInr}
              onChange={(e) => setForm({ ...form, minAmountInr: e.target.value })}
            />
            <Select
              label="Restrict to Plan"
              value={form.planId}
              onChange={(e) => setForm({ ...form, planId: e.target.value })}
              placeholder="All plans"
              options={[
                { value: '2', label: 'Basic' },
                { value: '3', label: 'Premium' },
                { value: '4', label: 'Family' },
              ]}
            />
          </div>
          <Input
            label="Expiry Date (blank = never)"
            type="datetime-local"
            value={form.expiresAt}
            onChange={(e) => setForm({ ...form, expiresAt: e.target.value })}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
            <Button type="submit" loading={loading} icon={<Plus size={15} />}>
              Create Coupon
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
