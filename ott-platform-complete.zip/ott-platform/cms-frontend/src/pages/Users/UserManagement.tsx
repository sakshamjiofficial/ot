import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Search, UserX, Shield, Users, UserCheck } from 'lucide-react';
import { usersApi }        from '@/api/endpoints';
import { DataTable }       from '@/components/DataTable/DataTable';
import { Input, Badge, ConfirmDialog, Card, StatCard, StatusBadge } from '@/components/UI';
import { formatDate, timeAgo } from '@/utils/cn';
import type { AdminUser }  from '@/types';
import toast from 'react-hot-toast';

export default function UserManagement() {
  const [page, setPage]       = useState(1);
  const [search, setSearch]   = useState('');
  const [deactivateId, setDeactivateId] = useState<string | null>(null);
  const queryClient           = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ['users', { page, search }],
    queryFn:  () => usersApi.list({ page, limit: 20, search: search || undefined }),
    placeholderData: (prev) => prev,
  });

  const deactivateMutation = useMutation({
    mutationFn: (id: string) => usersApi.deactivate(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast.success('User deactivated');
      setDeactivateId(null);
    },
    onError: () => toast.error('Failed to deactivate user'),
  });

  const users: AdminUser[] = data?.data ?? data?.items ?? [];
  const meta               = data?.meta ?? { total: 0, page: 1, limit: 20, totalPages: 1 };

  const columns = [
    {
      key:    'user',
      header: 'User',
      render: (row: AdminUser) => (
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-500/20 text-sm font-bold text-brand-400 uppercase">
            {row.displayName?.[0] || row.email[0]}
          </div>
          <div>
            <p className="font-medium text-white">{row.displayName || '—'}</p>
            <p className="text-xs text-surface-300">{row.email}</p>
          </div>
        </div>
      ),
    },
    {
      key:    'role',
      header: 'Role',
      render: (row: AdminUser) => (
        <div className="flex items-center gap-2">
          {row.role === 'superadmin' && <Shield size={14} className="text-brand-400" />}
          {row.role === 'admin' && <Shield size={14} className="text-blue-400" />}
          <span className={`text-sm capitalize ${
            row.role === 'superadmin' ? 'text-brand-400' :
            row.role === 'admin'      ? 'text-blue-400'  : 'text-surface-200'
          }`}>
            {row.role}
          </span>
        </div>
      ),
    },
    {
      key:    'status',
      header: 'Status',
      render: (row: AdminUser) => (
        <div className="flex flex-col gap-1">
          <StatusBadge status={row.isActive ? 'active' : 'archived'} />
          {row.isEmailVerified
            ? <Badge variant="success">✓ Verified</Badge>
            : <Badge variant="warning">Unverified</Badge>}
        </div>
      ),
    },
    {
      key:      'lastLoginAt',
      header:   'Last Login',
      sortable: true,
      render:   (row: AdminUser) => (
        <span className="text-xs text-surface-300">
          {row.lastLoginAt ? timeAgo(row.lastLoginAt) : 'Never'}
        </span>
      ),
    },
    {
      key:      'createdAt',
      header:   'Joined',
      sortable: true,
      render:   (row: AdminUser) => (
        <span className="text-xs text-surface-300">{formatDate(row.createdAt)}</span>
      ),
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        <StatCard label="Total Users"  value={meta.total} icon={<Users size={18} />}     color="blue" />
        <StatCard label="Active"       value={users.filter((u) => u.isActive).length}   icon={<UserCheck size={18} />} color="green" />
        <StatCard label="Admins"       value={users.filter((u) => u.role !== 'user').length} icon={<Shield size={18} />} color="red" />
      </div>

      {/* Search */}
      <Input
        className="max-w-sm"
        placeholder="Search by name or email…"
        leftIcon={<Search size={14} />}
        value={search}
        onChange={(e) => { setSearch(e.target.value); setPage(1); }}
      />

      {/* Table */}
      <Card padding={false}>
        <DataTable
          columns={columns}
          data={users}
          isLoading={isLoading}
          keyField="id"
          emptyMessage="No users found"
          rowActions={(row: AdminUser) => (
            <button
              onClick={() => setDeactivateId(row.id)}
              disabled={row.role === 'superadmin'}
              className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs text-surface-400 hover:bg-red-500/10 hover:text-red-400 transition-colors disabled:opacity-30 disabled:pointer-events-none"
            >
              <UserX size={12} />
              Deactivate
            </button>
          )}
          pagination={{
            page:       meta.page,
            limit:      meta.limit,
            total:      meta.total,
            totalPages: meta.totalPages,
            onPage:     setPage,
          }}
        />
      </Card>

      <ConfirmDialog
        open={!!deactivateId}
        title="Deactivate User"
        description="This will immediately log the user out of all devices and prevent future logins. Their content and history will be preserved."
        confirmLabel="Deactivate"
        danger
        onConfirm={() => deactivateId && deactivateMutation.mutate(deactivateId)}
        onCancel={() => setDeactivateId(null)}
      />
    </div>
  );
}
