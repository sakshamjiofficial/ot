package com.ott.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.ott.app.presentation.navigation.AppNavigation
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

@AndroidEntryPoint
class MainActivity : ComponentActivity(), PaymentResultListener {

    var razorpayCallback: ((success: Boolean, paymentId: String?, error: String?) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Checkout.preload(applicationContext)
        setContent {
            MaterialTheme {
                AppNavigation(
                    modifier = Modifier.fillMaxSize().background(Color(0xFF0A0A0A))
                )
            }
        }
    }

    override fun onPaymentSuccess(razorpayPaymentId: String, response: com.razorpay.PaymentData?) {
        Timber.d("Razorpay success: $razorpayPaymentId")
        razorpayCallback?.invoke(true, razorpayPaymentId, null)
        razorpayCallback = null
    }

    override fun onPaymentError(code: Int, description: String, response: com.razorpay.PaymentData?) {
        Timber.w("Razorpay error code=$code: $description")
        razorpayCallback?.invoke(false, null, "$code: $description")
        razorpayCallback = null
    }
}
